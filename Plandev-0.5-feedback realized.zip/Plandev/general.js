
function add_footer()
{
var footer='
<footer>
	<p>&copy;Copyright 2016 Fulton Shaw</p>
</footer>
'

}
