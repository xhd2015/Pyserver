#!/bin/python3
import os

def listdir_R(s,f):
	if os.path.isdir(s.html_dir+'/'+f):
		res=f+'\n'
		for i in os.listdir(s.html_dir+'/'+f):
			res+=listdir_R(s,f+'/'+i)
	else:
		res='<a href="'+f+'">'+f+'</a>'+'\n'
	return res

def generate_html(s):
	localdir=listdir_R(s,'')
	title='debug info'
	script=r'''
function load_more()
{
	var container=document.getElementById('container')
	var pre=document.createElement('pre')
	pre.appendChild(document.createTextNode('more'))
	container.appendChild(pre)
}
'''
	body=r'''
<div id='container'>
	<h4 id='preview'>概览信息</h4>
	<pre>'''+s.helpinfo+r'''</pre>
	
	<h4 id='setups'>配置参数</h4>'''
	setups=''
	for k in s.setups:
		setups+=k+'='+s.setups[k]+'\n'
	body+=r'''<pre>'''+setups+r'''</pre>
	<h4 id='argv'>命令行参数</h4>
	<pre>'''+str(s.argv)+r'''</pre>
	<h4 id='htmldir-content'>本地目录html</h4>
	<pre>'''+localdir+r'''
</div>
<div id='footer'>
	<u id='content-loader' style='cursor: pointer;' onclick='load_more();'>加载更多</u>
<div>
'''

	html=s.hf.format_html(body=body,title=title,script=script)
	return ['',html]
