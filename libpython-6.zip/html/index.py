#!/bin/python3

import time

    
def generate_html(s):
    hf=s.hf
    sq=s.sq
    '''响应式设计范例'''
    script=r'''
    /*1em=16px ， 通常，内部em用来指代父元素字体的像素*/
	window.addEventListener('load',function(e){
			btn_update=document.getElementById('btn_update');
			update_content=document.getElementById('content');
			/*ajax  使用，获取data*/
			btn_update.addEventListener('click',getUpdatedData,false);
	},false);
	function getUpdatedData(e)
	{
		if(update_content.value)
		{
			var xhr=new XMLHttpRequest();
			xhr.open('POST','/upload.html',true);//使用异步
			//===================process when data returned
			xhr.onreadystatechange=function(){
								if(xhr.readyState==4 && xhr.status==200)
								{
									//传回json数据
									var rtnData=JSON.parse(xhr.responseText);//date:,id:
									
									var lister=document.getElementById('lister');
									var newItem=document.createElement('pre');
									newItem.innerHTML=update_content.value+'\n<i>'+rtnData['date']+'</i><button onclick="postDeleteData(this);" content_id="'+rtnData['id']+'">删除</button>';
									lister.insertBefore(newItem,lister.childNodes[2]);
									update_content.value='';
								}
							};
			xhr.send(update_content.value);//或者textarea.value,由于使用post，所以data不必使用escape或者encodeURI
			//===============
		}
	}
	function postDeleteData(which)
	{
		var xhr=new XMLHttpRequest();
		xhr.open('GET','/delete.html?id='+which.getAttribute('content_id'),true);//使用异步
		xhr.onreadystatechange=function(){
				if(xhr.readyState==4 && xhr.status==200)
				{
					if(xhr.responseText==which.getAttribute('content_id'))//如果返回的id是同一个
					{
						pNode=which.parentNode;//pre
						ppNode=pNode.parentNode;//lister
						if(pNode && ppNode)
						{
							ppNode.removeChild(pNode);
						}
					}
				}
		};
		xhr.send();
	}
 '''
    qz_title='AQzLike'
    qz_style=r'''
div#container{
width: 100%;
}
div#prompter{
background-color: #99bbbb;
width: 100%;
}
div#lister{
width: 100%;
}
p#foot_content{
float: center;
}
#updater textarea{
	width: 100%;
	height: 5em;
}

#search_form input[name=scontent]{
	width: 70%;
}
#search_form input[value=查找]{
    width:  20%;
}
'''
    qz_body=r'''
<div id='container'>
	<div id='prompter'>
		<label>----内容----</label>
	</div>
	<div id='inputter'>
		<!-- 原来的提交是一个form，暗示着页面跳转，现在，使用ajax技术只取回更新的数据 -->
		<div id='updater'>
			<textarea name="content" id="content"></textarea>
			<br/>  <!--我去年换了个行-->
			<input type="checkbox" value='c' name='clear' disabled='disabled'>清除</input>
			<button type="submit"  id='btn_update'>提交</button>
		</div>
			
		<form action='/search.html' method='post' id='search_form'>
				<input type='text' name='scontent'/>
				<input type='submit' value='查找'/>
		</form>
	</div>
	<div id='lister'>
	<hr/>
'''

    with sq.connect(s.dbs) as conn:
        c=conn.cursor()
        c.execute('SELECT * FROM alldata')
        data=c.fetchall()
        for ctn in reversed(data):
            dateString=s.formatTime(ctn[2])
            precnt=ctn[1].replace('&','&amp;')
            precnt=precnt.replace('<','&lt;')
            precnt=precnt.replace('>','&gt;')
            qz_body+=s.content_fmt.format(content=precnt,date=dateString,id=ctn[0])
    qz_body+=r'''
    	</div>
  	<footer>
     	  <p id='foot_content'><u>http://www.you.cannot.visit.com</u></p>
  	</footer>
</div>
'''
    
    qz_html=hf.format_html(title=qz_title,script=script,style=qz_style,body=qz_body)
    return [0,qz_html]
