#!/bin/python3
import os

def listdir_R(s,f):
	if os.path.isdir(s.html_dir+'/'+f):
		res=f+'\n'
		for i in os.listdir(s.html_dir+'/'+f):
			res+=listdir_R(s,f+'/'+i)
	else:
		res='<a href="'+f+'">'+f+'</a>'+'\n'
	return res

def generate_html(s):
	localdir=listdir_R(s,'')
	head=''
	script=r'''</script>
	<script src='/jquery-3.1.0.min.js'></script>
	<script>
		$(document).ready(function(e){
			$('#footer_toggle').click(function(e){
				if($('footer').attr('isShown')=='true'){
					$('#footer_main').fadeOut();
					$('footer').attr('isShown','false');
				}else{
					$('#footer_main').fadeIn('slow');
					$('footer').attr('isShown','true')
				}
				
			});
		});
	'''
	title='Debug Info'
	style=r'''
	body{
		background-color: transparent;
	}
	fulton{
		font-weight:bold;
		font-variant:small-caps;
		font-style:italic;
		font-size:2em;
	}
	footer{
		position:fixed;
		bottom:0;
		width: 100%;
		background-color:rgb(2,60,90);
	}
	'''
	body=r'''
	<nav style="border:1px solid;background-color: lightblue;">
		<h1 style='text-align:center;;'>Debug Info for <fulton>Fulton</fulton></h1>
		<ul>
			<li>概览信息</li>
			<li>配置参数</li>
			<li>meta常量<sup>示例</sup></li>
			<li>headers常量<sup>示例</sup></li>
			<li>本地目录html</li>
			<li>Internet概念解释</li>
			<li>Shell 内置命令</li>
		</ul>
	</nav>
<article id='container' style="background-color:white;">
	<h4 id='preview'>概览信息</h4>
	<pre>'''+s.helpinfo+r'''</pre>
	
	<h4 id='setups'>配置参数</h4>'''
	setups=''
	for k in s.setups:
		setups+=k+'='+s.setups[k]+'\n'
	body+=r'''<pre>'''+setups+r'''</pre>
	<h4 id='argv'>命令行参数</h4>
	<pre>'''+str(s.argv)+r'''</pre>
	<h4 id='metas'>meta常量<sup>示例</sup></h4>
	<pre>'''+str(s.examples['metas'])+r'''</pre>
	<h4 id='headers'>headers常量<sup>示例</sup></h4>
	<pre>'''+str(s.examples['headers'])+r'''</pre>
	<h4 id='htmldir-content'>本地目录html</h4>
	<pre>'''+localdir+r'''</pre>
	<h4 id='inet-helper'>Internet概念解释</h4>
	<p>A generic URI is of the form:<br />
	&nbsp;&nbsp;&nbsp;&nbsp;scheme:[//[user:password@]host[:port]][/]path[?query][#fragment]
	</p>
	<h4 id='shell'>Shell 内置命令</h4>
	<p>
		<ul>
			<li>declare ： 设置变量，函数</li>
			<li>set : 设定shell的行为</li>
			<li>hash : 为执行文件指定快捷名称</li>
			<li>enable : 启用或禁用shell内置命令</li>
			<li>exec : 使用新的进程替换原来的进程 </li>
			<li>kill : 发送信号给进程</li>
		</ul>
	</p>
	<h4 id='linux-shell'>Linux 命令</h4>
	<ul>
		<li>service : 服务启动、停止或者重新启动；<br />
		示例：service httpd status；<br />
		相关命令：serviceconf(图形界面)；<br />
		介绍：所有的服务脚本在/etc/init.d下面 , service httpd x1 x2命令将会传递x1,x2参数给httpd , 大多数服务的x1参数为start , restart ,stop等。status命令-->[- 停止 +运行?不支持status命令]. /etc/init.d为System V的初始化脚本，/etc/init为新启用的脚本（非系统脚本） <br/>
		禁用服务 : 通过对/etc/init中相应的文件名称的改变，可以禁用某些服务.譬如sudo mv /etc/init/cups-browsed.conf /etc/init/cups-browsed.conf.disabled<br />
		由于/etc/rcX.d表示的是在运行级别X下相应的启动文件(S)，也就是服务，而这些服务实际上都是/etc/init.d的链接，所以如果将这些连接删除，就可以避免启动此类服务ls /etc/rc?.d/*cups*|
		</li>
		<li>wget : 从指定位置下载文件；和浏览器的区别在于，它不会分析文件内容，然后下载依赖文件</li>
		<li>elinks/lynx : 文本浏览器</li>
		<li>w : 显示当前登录的用户</li>
		<li>who : 当前登录系统的用户信息</li>
		<li>users : 显示所有在线用户</li>
		<li>finger : 查询用户信息，与cat /etc/passwd差不多</li>
		<li>chfn : 改变用户信息</li>
		<li>chsh : 改变默认登录shell</li>
		<li>passwd : 改变用户密码</li>
		<li>useradd/userdel : 添加/删除用户，这两个指令只能以root运行，需要修改/etc/passwd文件</li>
		<li>login : 登录一个域上的系统</li>
		<li>init /telinit: 改变系统级别；0.关机 1 .单用户root，用于维护系统 2.无nfs服务的3模式   3.完全多用户网络模式，服务器默认模式  4.未使用  5.图形界面模式  6.重启系统</li>
		<li>uname : 显示系统信息</li>
		<li>host  :  查询dns</li>
		<li>mount : mount /dev/sda1 /media/x/C 挂载硬盘</li>
		<li>umount : 卸载挂载的硬盘</li>
		<li>sync : 将所有缓存的数据存入磁盘</li>
		<li>pstree : 显示进程树</li>
		<li>uptime : --pretty 显示系统运行时间</li>
		<li>lsmod / modinfo :  显示模块信息</li>
		<li>insmode / modprobe : 加载模块</li>
		<li>rmmod: 删除模块</li>
		<li>sysctl  : 控制系统内核参数；系统参数保存在/etc/sysctl.conf中。一个示例：关闭ip路由----&gt;sysctl net.ipv4.ip_forward=0</li>
		<li>
		find :-name 指定名字模式，支持通配符；find符合标准的参数解析（除了用长参数替代短参数），其目标是目录。<br />
		-type 指定文件类型f <br />
		-exec 对查找到的文件执行命令，最后一个参数必须以';'结束，在命令中使用{}表示文件 ;可以连续使用多个-exec参数<br />
		 </li>
		 <li>arp , arping , arpwatch : 显示本机arp ，邻近主机arp信息或者监听。记住，arp只能用于同一个域，并且域与接口是相关的;arpwatch以服务模式启动，当有变化时记录到syslog中
		 </li>
		 <li>ipcalc : 计算ip地址的广播地址等。</li>
		 <li>ln : 将文件当做数组，inode当做下标，则文件实际上是一个指针，而文件夹则是指针数组，文件指向文件内容的位置。硬链接是创建新的指针（共享内容），软链接创建指针的指针（父子关系）。</li>
		<li>vsftpd : 在linux上开启ftp服务；</li>
		<li>ftp : 获取服务器上的文件</li>
		<li>whois : 查询dns数据库中某个域名的详细信息</li>
		<li>kill/killall : kill对pid操作，killall对进程名称</li>
		<li>chkconfig : 配置系统服务</li>
	</ul>
	<section id='python-info'>
		<h4>Python库帮助</h4>
		<ul>
			<li>
			ftplib : FTP() login()  cwd()  mkd()  pwd()   getwelcome() delete() dir()--->'LIST'  nlst()-->'NLST' <br />
			retrlines('LIST',callback---->f(line)--->default:sys.stdout)-->get ls     <br />
			retrbinary('RETR filename'-->cmd,f.write-->callback)  <br />
			<b>use with</b> with FTP(...) as f: 
			</li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>' 
		</ul>
	</section>
	<section id='database-info'>
		<h4>数据库帮助信息</h4>
		<ul>
			<li>数据库查找  :<b>IN 条件语句 </b> ... WHERE col IN (val1,val2,...) <br />
			<b>LIKE 条件语句 </b>LIKE也是一个条件语句，但是LIKE的用处在于其后面的操作数：支持通配符。{% : 零个或多个, _ : 一个  , [charlist]:字符列表 , [^charlist]:非字符列表 }
			</li>
			<li>AUTO_INCREMENT : 用在create table中，指的是int型数据在创建时自动增1</li>
			<li>PRIMARY KEY (col1,col2,...) :创建主键,通常在create table中的最后一行指定；然而，PRIMARY KEY也可以用在通常的列中</li>
			<li>UNION : 对多个集合的并运算，返回的结果总是以第一个表为参照 </li>
			<li>ALTER : 修改表信息；对于sqlite3，支持ALTER TABLE tab {RENAME TO new_tab,ADD COLUMN colname column_def},也就是说只能更改表名或者添加列</li>
			<li>子查询 : 子查询使用(selections)作为语法，可以认为子查询构成一个多值集合；因此可以对子查询使用IN等操作符</li>
			<li>子查询插入insert : 其关键是不需要使用values。INSERT INTO tab SELECT x,y FROM tab</li>
		</ul>
	</section>
	<section id='network-scan'>
		<h4>网络扫描和系统安全</h4>
		<ul>
			<li>ping : ping与计算机端口无关，它用于发现开启的计算机</li>
			<li>telnet : 连接到计算机的某个服务，如telnet localhost echo,连接到echo服务</li>
			<li>fping : 同时发送多个包到目标网络集合</li>
			<li>nmap : 使用nmap提供-sP选项，提供ip地址和掩码长度，即可实现ping. nmap -sP localhost/24 <br/>
					端口扫描 <br />
					操作系统检测 <br />
			</li>
			<li>traceroute : 发现一个到目标主机最近的路径</li>
			<li>netcat : 主机端口扫描工具;nc是其简称；-w [n]超时，-v详细格式，-z只连接，不发送数据 -u查询udp端口;nc -vzw 4 www.example.com 1-65535</li>
			<li>嗅探器 : 用于截取网路上发送的数据包；hunt ， linux-sniff , </li>
			<li></li>
			<li>lsof  : 获取计算机上运行的服务 , (其中由inid启动的部分)</li>
			<li>netstat : -an 选项通常用于查看计算机的链接信息.使用sudo获得服务的进程号。</li>
			<li></li>
			<li></li>
		</ul>
	</section>
</article>
<br/>
<br/>
<br/>
<br/>
<footer>
	<div style='background-color:white;'><img id='footer_toggle' src='/favicon.ico' style='width:2%;height:1%;margin-left:50%;'></img></div>
	<div id='footer_main'>
	<hr style="width:100%;"/>
	<p style='text-align:center;font-size:medium;'><small>&copy;</small>copyright <fulton>Fulton Shaw</fulton> since 2012</p>
	</div>
</footer>
'''

	html=s.hf.format_html(script=script,head=head,body=body,style=style,title=title)
	return [0,html]
