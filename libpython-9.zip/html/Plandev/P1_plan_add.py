


'''
我们将设计划分为以下几部分:
	1.设计输入  --  这个可以由一般的函数生成,html生成
	2.输入获取  --  同上,javascript生成
	3.提交并在服务器端存储  --  使用sqlite和python完成
	4.查看所有的计划

设计需要注意的一些细节:
	1.将某些函数通用化
		比如生成JSON数据的表单
	2.输入的字符串去除首尾空白(当然,最好不要这样做)

******帮助信息
each函数
	$(selector).each(function(index,element)) , index位置,element为元素
'''

import __plandev_library as plandev

def generate_html(s):
	#目前还不支持处理可变的同类型数据
	title="Addddd"
	body=r'''<p>Welcome</p>
	<div id="adder">
		Name <input type="text" class="name"></input> <br/>
		Description <input type="text" class="description"></input> <br/>
		Universal <input type="text" class="universal"></input> <br/>
		Part 1 <input type="text" class="partial"></input> <br/>
		Part 2 <input type="text" class="partial"></input> <br/>
		Part 3 <input type="text" class="partial"></input> <br/>
		Part 4 <input type="text" class="partial"></input> <br/>
		Part 5 <input type="text" class="partial"></input> <br/>
		<button type="button" onclick="addPlan(this);">Add</button>
		<button type="button" onclick="clearInput(this);">Clear</button>
	</div>
	<a href="/Plandev/P1_plan_showitems.html" target="_blank">Show All Plans</a>
	<div id="pending">
		<p class="prompt"></p>
	</div>

'''
	
	head=r''''''
	script=r'''
</script><script src='/jquery-3.1.0.min.js'></script><script>
function setPrompt(text){
	$("#pending").find(".prompt").text(text);
}
function addPlan(argBtn){
	var $adder=$(argBtn).parent();
	
	//确保:是真正的分隔符号,使用url_quote将
	// : --  %3A
	// { --  %7B
	// } --  %7D
	// , --  %2C

	var starting="{\n";
	var data=starting;
	var mappings=["name","description","universal","partial"];
	for(var i in mappings)
	{
		$adder.find("."+mappings[i]).each(function(index,element){
			if(data!=starting)
				data+="\n"
				
			//将元字符串转义
			var v=$(element).val();
			var lst={ 
				":":"%3A",
				"{":"%7B",
				"}":"%7D",
				",":"%2C"
			};
			for(var j in lst){
				v=v.replace(new RegExp(j,"g"),lst[j])
			}
			
			
			data+=mappings[i]+":"+v+",";
		});	
	}
	data+="\n}";
	$.post("/Plandev/ajax-services/addbook.html",data,function(resp){
		if(resp=="-1")
		{
			setPrompt("failed");
		}else{
			setPrompt("successful,id is "+resp);
		}
	});
}

function clearInput(argBtn){
	$(argBtn).parent().find("input").val("");

}
$(document).ready(function(){

	
});	

'''
	body+=plandev.get_content(s.html_dir+"/Plandev/footer.html")

	html=s.hf.format_html(title=title,head=head,script=script,body=body)
	return [0,html]
