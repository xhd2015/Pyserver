
def generate_html(s):
	head=''
	style=''
	title="Quertssss"
	script=r'''
	</script><script src='/jquery-3.1.0.min.js'></script><script>
	function setSingleItem($item,stuff)
	{
		for(var i in stuff)
		{
			$item.find("."+i).html(stuff[i]);
		}
	}
	function showAllItems(respdata)
	{
		clearAllShown();
		$holder=$("#items_holder")
		$template=$holder.find(".item_show_example");
		
		for(var i in respdata)
		{
				$cloned=$template.clone().show();
				$holder.append($cloned);
				setSingleItem($cloned,respdata[i]);
		}
	}
	function clearAllShown()
	{
		$("#items_holder").find(".item_show").remove();
	}
	function getAllPlanData()
	{
		//q=[all] 表明查询所有数据
		//不要在查询中使用多值键
		getPlanData({"q":"[all]"});
	}
	//pattern是形如 {q:xxx}的形式,q,xxx中  { = & ? / : } , 被转义
	function getPlanData(pattern)
	{
		$.post("/Plandev/ajax-services/findplans.html",JSON.stringify(pattern),function(resp){
			data=JSON.parse(resp);
			showAllItems(data);
		});
	}
	
	$(document).ready(function(){
		getAllPlanData();
	});
'''
	#对于show item, 所有的class必须与返回的key相同,并且支持html()方法设置参数
	#定义返回的数据为JSON解析
	body=r'''
	<div class="freeform">
		<input type="text"></input>
		<button onclick="getInputData(this);">Search</button>
	</div>
	<hr/>
	<div id="items_holder">
		<div class="item_show_example" style="display:none">
			<p>*********************************</p>
			<p class="id" style="display:none">Plan Id</p>
			title : <label class="title">Name</label> <br/>	
			description : <span class="description">Description</span> <br/>
			univeral : <span class="universal">Universal</span> <br/>
			<ul>
				<li><p class="p1">p1</p></li>
				<li><p class="p2">p2</p></li>
				<li><p class="p3">p3</p></li>
				<li><p class="p4">p4</p></li>
				<li><p class="p5">p5</p></li>
			</ul>
		</div>
	</div>
'''
	
	html=s.hf.format_html(title=title,body=body,head=head,script=script,style=style)
	return [0,html]
