
import __plandev_library as plandev
import urllib.parse
def processed_data(data):
	#专门为add的数据处理
	trnslist={
		"%3A":":",
		"%7B":"{",
		"%7D":"}",
		"%2C":","
	}
	#将所有的url_quote的数据转换成正常的数据
	return urllib.parse.unquote(data)
	
#获取符合查询条件所有id
def get_id(cur,data):
	
	#构造查询字符串,使用and条件连接
	sqlexe="Select id From Plan_P1 Where ";
	conditions=[]
	previous=False
	for key in data:
		if previous:
			sqlexe+="and "
		sqlexe+=key+"= ? ";
		conditions.append(data[key])
		previous=True
	
	cur.execute(sqlexe,conditions)
	rs=cur.fetchall() #不会返回None,而是返回空列表.由于我们希望返回值统一,所以,返回好一点的东西吧
	print(rs)
	if rs:
		return [i[0] for i in rs]
	else:
		return []
			
def generate_html(s):
	data=s.sf.getPostData(s)
	data=data.decode("u8")
	#原始data模式
	'''
	{
	name:fds,
	description:sdf,
	universal:sdf,
	partial:sdf,
	partial:d,
	partial:df,
	partial:d,
	partial:s
	}
	'''
	data_pattern=r'''
		\{?\s? #match empty start
		([^:]*):([^,]*)  #key:value
		,\}?  #match empty end
	'''
	data=plandev.parse_data(data,data_pattern)
	
	
	#database 模式
	#table: Plan_P1
	#id integer auto_increment primary key,title text not null,description text,universal text,p1 text,p2 text,p3 text,p4 text,p5 text
	id=-1;
	with s.sq.connect(s.dbs) as conn:

		cur=conn.cursor()
		
		#执行一次, 添加表格
		#cur.execute("Create Table Plan_P1(id integer primary key autoincrement,title text not null,description text,universal text,p1 text,p2 text,p3 text,p4 text,p5 text)")
		#conn.commit()

		#查询数据库中是否存在完全相同的计划
		#构造查询id的条件
		sqlkeys=["title","description","universal","p1","p2","p3","p4","p5"]
		sqldata={}
		for i in range(len(sqlkeys)):
			sqldata[sqlkeys[i]]=processed_data(data[i][1])
		ids=get_id(cur,sqldata)
		if ids:#已经存在同样的数据
			pass
		else:
			#将数据插入
			sqlexecute="Insert Into Plan_P1(title,description,universal,p1,p2,p3,p4,p5) Values(?,?,?,?,?,?,?,?);"
			valuelist=[]

			
			for pair in data:
				#先把转义的字符还原
				valuelist.append(processed_data(pair[1]))
			cur.execute(sqlexecute,valuelist)
			conn.commit()
			
			#获取插入的id
			ids=get_id(cur,sqldata)
			id=ids[0]
		
	#返回id的值告知其
	return [0,str(id)]
